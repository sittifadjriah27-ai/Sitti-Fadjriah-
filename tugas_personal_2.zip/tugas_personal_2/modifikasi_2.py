"""
TUGAS PERSONAL 2 — Modifikasi Level 6–9 (DIKERJAKAN MAHASISWA)
========================================================

Setiap modifikasi mengubah kode level sebelumnya agar memakai data pribadi
mahasiswa dan menghasilkan angka yang BISA DIHITUNG ULANG (deterministik).

Jalankan:  python tugas_personal_2/jalankan_tugas_2.py
"""

import hashlib

from ecdsa import SECP256k1, SigningKey

import level06_difficulty as L6
import level07_tanda_tangan as L7
import level08_jaringan as L8
import level09_reward_saldo as L9


# ============================================================== MODIFIKASI 6
def jejak_difficulty(awal: int, daftar_waktu: list, target: float) -> list:
    """Terapkan L6.sesuaikan_difficulty berulang kali.

    Mulai dari difficulty `awal`. Untuk setiap waktu di `daftar_waktu` (berurutan),
    hitung difficulty baru dari difficulty saat ini. Kembalikan list semua
    difficulty SETELAH setiap langkah (panjangnya = len(daftar_waktu)).

    Contoh: jejak_difficulty(4, [1, 5, 30], 10) -> [5, 5, 4]
    """
    # TODO: lengkapi
    # Petunjuk: Simpan difficulty saat ini di variabel, lalu loop daftar_waktu
    # Petunjuk: Setiap langkah panggil L6.sesuaikan_difficulty(...) dan append hasilnya
    raise NotImplementedError("TODO: jejak_difficulty")


# ============================================================== MODIFIKASI 7
def kunci_dari_data(nama: str, nim4: str, tanggal_lahir: str):
    """Buat pasangan kunci SECP256k1 yang SELALU SAMA untuk data yang sama.

    secret = int(SHA-256(f"{nim4}:{nama}:{tanggal_lahir}"), 16) % SECP256k1.order
    (jika hasilnya 0, pakai 1). Lalu SigningKey.from_secret_exponent(secret, curve=SECP256k1).
    Kembalikan (kunci_privat_hex, kunci_publik_hex), format sama seperti Level 7.

    PERINGATAN: ini hanya untuk latihan. Kunci asli TIDAK BOLEH dibuat dari data
    yang bisa ditebak orang lain.
    """
    # TODO: lengkapi
    # Petunjuk: Hitung secret dari hashlib.sha256(...).hexdigest() lalu int(..., 16) % SECP256k1.order
    # Petunjuk: sk = SigningKey.from_secret_exponent(secret, curve=SECP256k1)
    # Petunjuk: Kembalikan seperti L7.buat_pasangan_kunci: .to_string().hex()
    raise NotImplementedError("TODO: kunci_dari_data")


def tanda_tangani_deterministik(tx: dict, kunci_privat_hex: str) -> str:
    """Seperti L7.tanda_tangani, tetapi memakai sign_deterministic (RFC 6979),
    sehingga transaksi dan kunci yang sama SELALU menghasilkan tanda tangan yang sama.
    Pesan yang ditandatangani: L7.pesan_transaksi(tx).
    """
    # TODO: lengkapi
    # Petunjuk: Mirip L7.tanda_tangani, ganti .sign(...) dengan .sign_deterministic(...)
    raise NotImplementedError("TODO: tanda_tangani_deterministik")


# ============================================================== MODIFIKASI 8
class NodePersonal(L8.Node):
    """Node Level 8 yang menandai setiap blok tambangannya.

    tambang_blok(transactions) menambang blok dengan daftar transaksi
    [f"{self.nama}#{self.nim4}"] + transactions  (penanda di posisi pertama).
    Gunakan tambang_blok milik kelas induk (super()).
    """

    def __init__(self, nama: str, nim4: str, difficulty: int = 2):
        super().__init__(nama, difficulty)
        self.nim4 = nim4

    def tambang_blok(self, transactions) -> dict:
        # TODO: lengkapi
        # Petunjuk: return super().tambang_blok([...penanda...] + list(transactions))
        raise NotImplementedError("TODO: tambang_blok di NodePersonal")


def semua_sepakat(nodes: list) -> bool:
    """True jika rantai semua node sama persis."""
    # TODO: lengkapi
    # Petunjuk: Bandingkan n.chain setiap node dengan nodes[0].chain
    raise NotImplementedError("TODO: semua_sepakat")


# ============================================================== MODIFIKASI 9
class BlockchainHalving(L9.Blockchain):
    """Blockchain Level 9 dengan hadiah mining yang berkurang separuh (halving),
    seperti Bitcoin.

    hadiah(index) = hadiah_awal // 2 ** ((index - 1) // interval)
      contoh hadiah_awal=40, interval=2: blok 1-2 = 40, blok 3-4 = 20, blok 5-6 = 10, ...

    Ubah mine() dan validasi_ekonomi() dari Level 9 agar memakai hadiah(index)
    sebagai pengganti konstanta MINING_REWARD.
    """

    def __init__(self, hadiah_awal: int, interval: int, difficulty: int = 2):
        super().__init__(difficulty)
        self.hadiah_awal = hadiah_awal
        self.interval = interval

    def hadiah(self, index: int) -> int:
        # TODO: lengkapi
        # Petunjuk: Gunakan // (pembagian bulat) dan ** (pangkat)
        raise NotImplementedError("TODO: hadiah di BlockchainHalving")

    def mine(self, alamat_penambang: str) -> dict:
        # TODO: lengkapi
        # Petunjuk: Salin mine() dari Level 9, ganti MINING_REWARD dengan self.hadiah(index)
        # Petunjuk: index blok baru = self.chain[-1]["index"] + 1; SISTEM ada di L9.SISTEM
        raise NotImplementedError("TODO: mine di BlockchainHalving")

    def validasi_ekonomi(self) -> bool:
        # TODO: lengkapi
        # Petunjuk: Salin validasi_ekonomi() dari Level 9
        # Petunjuk: Ganti pemeriksaan MINING_REWARD dengan self.hadiah(block["index"])
        raise NotImplementedError("TODO: validasi_ekonomi di BlockchainHalving")
