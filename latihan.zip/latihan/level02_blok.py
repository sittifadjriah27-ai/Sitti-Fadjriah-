
"""
LEVEL 2 — Blockchain Dasar ala GeeksforGeeks, tanpa Flask (LATIHAN)
=========================================================================

Kode ini adalah port dari artikel:
https://www.geeksforgeeks.org/python/create-simple-blockchain-using-python/

Tujuan belajar:
  * Struktur blok: index, timestamp, proof, previous_hash.
  * Menghubungkan blok dengan hash blok sebelumnya.
  * Proof of Work sederhana dan validasi rantai.

Jalankan tes: python cek_nilai.py 2
"""

import datetime
import hashlib
import json


class Blockchain:
    def __init__(self, difficulty: int = 4):
        self.difficulty = difficulty
        self.chain = []

        # Blok genesis (blok pertama)
        self.create_block(proof=1, previous_hash="0")

    # ---------- SUDAH DISEDIAKAN ----------
    def create_block(self, proof: int, previous_hash: str) -> dict:
        block = {
            "index": len(self.chain) + 1,
            "timestamp": str(datetime.datetime.now()),
            "proof": proof,
            "previous_hash": previous_hash,
        }
        self.chain.append(block)
        return block

    def last_block(self) -> dict:
        """(Di artikel GfG bernama print_previous_block)."""
        return self.chain[-1]

    # ---------- BAGIAN YANG DIKERJAKAN ----------
    def hash(self, block: dict) -> str:
        """SHA-256 dari blok yang diserialisasi JSON dengan sort_keys=True."""
        encoded_block = json.dumps(block, sort_keys=True).encode("utf-8")
        return hashlib.sha256(encoded_block).hexdigest()

    def valid_proof(self, previous_proof: int, proof: int) -> bool:
        """Memeriksa proof berdasarkan tingkat kesulitan."""
        guess = proof**2 - previous_proof**2
        guess_hash = hashlib.sha256(str(guess).encode("utf-8")).hexdigest()

        return guess_hash.startswith("0" * self.difficulty)

    def proof_of_work(self, previous_proof: int) -> int:
        """Mencari proof yang memenuhi persyaratan difficulty."""
        new_proof = 1

        while not self.valid_proof(previous_proof, new_proof):
            new_proof += 1

        return new_proof

    def mine_block(self) -> dict:
        """Menambang blok baru."""
        previous_block = self.last_block()

        previous_proof = previous_block["proof"]

        proof = self.proof_of_work(previous_proof)

        previous_hash = self.hash(previous_block)

        block = self.create_block(proof, previous_hash)

        return block

    def chain_valid(self, chain: list) -> bool:
        """Memeriksa validitas seluruh rantai blockchain."""

        for i in range(1, len(chain)):
            previous_block = chain[i - 1]
            current_block = chain[i]

            # Memeriksa hubungan hash antarblok
            if current_block["previous_hash"] != self.hash(previous_block):
                return False

            # Memeriksa Proof of Work
            if not self.valid_proof(
                previous_block["proof"],
                current_block["proof"]
            ):
                return False

        return True


if __name__ == "__main__":
    bc = Blockchain(difficulty=4)

    for _ in range(4):
        b = bc.mine_block()
        print(f"Blok #{b['index']} ditambang, proof={b['proof']}")

    print(json.dumps(bc.chain, indent=2))
    print("Rantai valid?", bc.chain_valid(bc.chain))
