"""
LEVEL 9 — Mining Reward, Saldo, dan Validasi Ekonomi (LATIHAN)
====================================================================

Inilah langkah menuju cryptocurrency sederhana:
  * Penambang mendapat hadiah (coinbase transaction) dari "sistem" (sender = "0").
  * Saldo setiap alamat dihitung dari SELURUH riwayat transaksi (model akun).
  * Transaksi ditolak jika saldo pengirim tidak cukup (mencegah double spending
    sederhana di dalam mempool).

Tujuan belajar:
  * Asal-usul koin baru (coinbase) dan total suplai.
  * Validasi ekonomi selain validasi kriptografis.

Jalankan tes:  python cek_nilai.py 9
"""


import hashlib
import json

SISTEM = "0"
MINING_REWARD = 10


class Blockchain:
    def __init__(self, difficulty: int = 2):
        self.difficulty = difficulty
        self.pending_transactions = []

        genesis = {
            "index": 0,
            "transactions": [],
            "previous_hash": "0" * 64,
            "nonce": 0
        }

        self._tambang(genesis)
        self.chain = [genesis]

    @staticmethod
    def hash_block(block):
        isi = {k: v for k, v in block.items() if k != "hash"}
        data = json.dumps(isi, sort_keys=True).encode()
        return hashlib.sha256(data).hexdigest()

    def _tambang(self, block):
        block["nonce"] = 0

        while not self.hash_block(block).startswith(
            "0" * self.difficulty
        ):
            block["nonce"] += 1

        block["hash"] = self.hash_block(block)
        return block

    def saldo(self, alamat: str, termasuk_pending: bool = True) -> float:
        # Kumpulkan semua transaksi dari blockchain
        semua_transaksi = []

        for block in self.chain:
            semua_transaksi.extend(block["transactions"])

        # Tambahkan transaksi yang masih menunggu jika diminta
        if termasuk_pending:
            semua_transaksi.extend(self.pending_transactions)

        # Hitung total saldo alamat
        total = 0

        for tx in semua_transaksi:
            if tx["recipient"] == alamat:
                total += tx["amount"]

            if tx["sender"] == alamat:
                total -= tx["amount"]

        return total

    def add_transaction(self, sender: str, recipient: str, amount) -> None:
        # Hanya sistem yang boleh membuat koin melalui mining
        if sender == SISTEM:
            raise ValueError("Sender sistem hanya boleh digunakan untuk mining")

        # Jumlah transaksi harus positif
        if amount <= 0:
            raise ValueError("Jumlah transaksi harus lebih dari 0")

        # Periksa saldo pengirim, termasuk transaksi pending
        if self.saldo(sender, termasuk_pending=True) < amount:
            raise ValueError("Saldo tidak mencukupi")

        # Masukkan transaksi ke daftar pending
        transaksi = {
            "sender": sender,
            "recipient": recipient,
            "amount": amount
        }

        self.pending_transactions.append(transaksi)

    def mine(self, alamat_penambang: str) -> dict:
        # Buat transaksi reward untuk penambang
        coinbase = {
            "sender": SISTEM,
            "recipient": alamat_penambang,
            "amount": MINING_REWARD
        }

        # Coinbase harus berada di posisi pertama
        transactions = [coinbase] + self.pending_transactions.copy()

        last = self.chain[-1]

        block = {
            "index": last["index"] + 1,
            "transactions": transactions,
            "previous_hash": last["hash"],
            "nonce": 0
        }

        # Tambang dan masukkan blok ke blockchain
        self._tambang(block)
        self.chain.append(block)

        # Kosongkan transaksi pending
        self.pending_transactions.clear()

        return block

    def total_suplai(self) -> float:
        total = 0

        for block in self.chain:
            for tx in block["transactions"]:
                if tx["sender"] == SISTEM:
                    total += tx["amount"]

        return total

    def validasi_ekonomi(self) -> bool:
        # Catat saldo setiap alamat
        saldo = {}

        # Genesis tidak memiliki transaksi ekonomi
        for block in self.chain[1:]:
            transactions = block["transactions"]

            # Setiap blok harus memiliki transaksi coinbase
            if not transactions:
                return False

            coinbase = transactions[0]

            # Coinbase harus berasal dari sistem
            if (
                coinbase["sender"] != SISTEM
                or coinbase["amount"] != MINING_REWARD
            ):
                return False

            # Tidak boleh ada transaksi sistem lainnya
            for tx in transactions[1:]:
                if tx["sender"] == SISTEM:
                    return False

            # Putar ulang seluruh transaksi secara berurutan
            for tx in transactions:
                sender = tx["sender"]
                recipient = tx["recipient"]
                amount = tx["amount"]

                # Jumlah transaksi harus positif
                if amount <= 0:
                    return False

                # Transaksi coinbase menambah saldo penerima
                if sender == SISTEM:
                    saldo[recipient] = saldo.get(recipient, 0) + amount
                else:
                    # Kurangi saldo pengirim
                    saldo[sender] = saldo.get(sender, 0) - amount

                    # Saldo tidak boleh negatif
                    if saldo[sender] < 0:
                        return False

                    # Tambahkan saldo penerima
                    saldo[recipient] = saldo.get(recipient, 0) + amount

        return True


if __name__ == "__main__":
    bc = Blockchain()

    bc.mine("ani")
    bc.add_transaction("ani", "budi", 4)
    bc.mine("citra")

    for nama in ("ani", "budi", "citra"):
        print(f"Saldo {nama}: {bc.saldo(nama)}")

    print("Total suplai:", bc.total_suplai())

    try:
        bc.add_transaction("budi", "dodi", 100)
    except ValueError as e:
        print("Ditolak:", e)

    print("Validasi ekonomi:", bc.validasi_ekonomi())
