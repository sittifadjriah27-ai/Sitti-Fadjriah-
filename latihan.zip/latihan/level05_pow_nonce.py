
"""
LEVEL 5 — Proof of Work yang Benar:
Hash Seluruh Isi Blok + Nonce (LATIHAN)
=================================================================================

Di Level 3 kita melihat kelemahan: proof GfG tidak bergantung pada isi blok,
sehingga penyerang cukup menyambung ulang previous_hash tanpa menambang ulang.

Perbaikan: yang di-hash adalah SELURUH isi blok, termasuk nonce.
Penambang mengubah nonce sampai hash blok diawali N angka nol.

Tujuan belajar:
  * Nonce dan target difficulty.
  * Mengapa mengubah satu blok memaksa penyerang menambang ulang
    SEMUA blok sesudahnya.

Jalankan tes: python cek_nilai.py 5
"""

import datetime
import hashlib
import json


class Blockchain:
    def __init__(self, difficulty: int = 3):
        self.difficulty = difficulty
        self.chain = []

        genesis = {
            "index": 0,
            "timestamp": str(datetime.datetime.now()),
            "transactions": [],
            "previous_hash": "0" * 64,
            "nonce": 0,
        }

        self.proof_of_work(genesis)
        self.chain.append(genesis)

    # ---------- BAGIAN YANG DIKERJAKAN ----------

    @staticmethod
    def hash_block(block: dict) -> str:
        """Menghitung SHA-256 dari seluruh isi blok tanpa key hash."""

        data = {
            key: value
            for key, value in block.items()
            if key != "hash"
        }

        encoded_block = json.dumps(
            data,
            sort_keys=True
        ).encode("utf-8")

        return hashlib.sha256(encoded_block).hexdigest()

    def proof_of_work(self, block: dict) -> int:
        """Mencari nonce sampai hash memenuhi difficulty."""

        block["nonce"] = 0
        percobaan = 0

        while True:
            hasil_hash = self.hash_block(block)
            percobaan += 1

            if hasil_hash.startswith("0" * self.difficulty):
                block["hash"] = hasil_hash
                return percobaan

            block["nonce"] += 1

    def new_block(self, transactions: list) -> dict:
        """Membuat dan menambang blok baru."""

        previous_block = self.chain[-1]

        block = {
            "index": previous_block["index"] + 1,
            "timestamp": str(datetime.datetime.now()),
            "transactions": transactions,
            "previous_hash": previous_block["hash"],
            "nonce": 0,
        }

        self.proof_of_work(block)

        self.chain.append(block)

        return block

    def chain_valid(self) -> bool:
        """Memeriksa validitas seluruh blockchain."""

        for i, block in enumerate(self.chain):

            # Memeriksa kesesuaian hash
            if block.get("hash") != self.hash_block(block):
                return False

            # Memeriksa difficulty
            if not block.get("hash", "").startswith(
                "0" * self.difficulty
            ):
                return False

            # Memeriksa hubungan dengan blok sebelumnya
            if i > 0:
                if block["previous_hash"] != self.chain[i - 1]["hash"]:
                    return False

        return True

    def tambang_ulang_dari(self, posisi: int) -> int:
        """Menambang ulang blok mulai posisi tertentu sampai terakhir."""

        total_percobaan = 0

        for i in range(posisi, len(self.chain)):

            block = self.chain[i]

            if i > 0:
                block["previous_hash"] = self.chain[i - 1]["hash"]

            total_percobaan += self.proof_of_work(block)

        return total_percobaan


if __name__ == "__main__":
    bc = Blockchain(difficulty=4)

    for tx in (
        ["Ani->Budi 5"],
        ["Budi->Citra 2"],
        ["Citra->Dodi 1"]
    ):
        b = bc.new_block(tx)

        print(
            f"Blok #{b['index']} "
            f"nonce={b['nonce']} "
            f"hash={b['hash'][:16]}..."
        )

    print("Valid?", bc.chain_valid())

    bc.chain[1]["transactions"] = ["Ani->Budi 500"]

    print("Setelah diubah valid?", bc.chain_valid())

    usaha = bc.tambang_ulang_dari(1)

    print(
        f"Penyerang menambang ulang dengan {usaha} "
        f"percobaan hash. Valid?",
        bc.chain_valid()
    )
