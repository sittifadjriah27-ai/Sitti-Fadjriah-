"""
TUGAS PERSONAL — Lima Modifikasi Level 1–5 (DIKERJAKAN MAHASISWA)
===========================================================

Setiap fungsi/kelas di bawah memodifikasi kode level sebelumnya agar memakai
data pribadi mahasiswa. Hasilnya berbeda untuk setiap mahasiswa.

Jalankan:  python tugas_personal/jalankan_tugas.py
"""


import level01_hash as L1
import level02_blok as L2
import level03_tampering as L3
import level05_pow_nonce as L5


# ============================================================== MODIFIKASI 1
def sidik_jari(nama: str, nim4: str, tanggal_lahir: str) -> str:
    """ID mahasiswa = 8 karakter pertama dari sha256_hex(f"{nim4}:{nama}:{tanggal_lahir}").

    Gunakan sha256_hex dari Level 1 (sudah diimpor sebagai L1).
    Contoh bentuk hasil: 'a3f09c1e'
    """
    # TODO: lengkapi
    # Petunjuk: return L1.sha256_hex(...)[:8] dengan f-string yang tepat
    raise NotImplementedError("TODO: sidik_jari")


# ============================================================== MODIFIKASI 2
class BlockchainPersonal(L2.Blockchain):
    """Blockchain Level 2 yang dipersonalisasi:
      * proof blok genesis = int(nim4)   (bukan 1 seperti di GfG)
      * SETIAP blok (termasuk genesis) punya field tambahan "pemilik" = id_mhs
    """

    def __init__(self, nim4: str, id_mhs: str, difficulty: int = 4):
        # Jangan memanggil super().__init__(), karena itu membuat genesis dengan proof=1.
        # TODO: lengkapi
        # Petunjuk: Set self.difficulty, self.id_mhs, self.chain = []
        # Petunjuk: Lalu buat genesis: self.create_block(proof=int(nim4), previous_hash="0")
        raise NotImplementedError("TODO: __init__ di BlockchainPersonal")

    def create_block(self, proof: int, previous_hash: str) -> dict:
        # TODO: lengkapi
        # Petunjuk: block = super().create_block(proof, previous_hash)
        # Petunjuk: Tambahkan block["pemilik"] lalu kembalikan block
        raise NotImplementedError("TODO: create_block di BlockchainPersonal")


# ============================================================== MODIFIKASI 3
def palsukan(chain: list, posisi: int):
    """Simulasi pemalsuan di Level 3.

    1. palsu     = ubah_blok(...) : data blok `posisi` ditambah teks " (DIPALSUKAN)"
    2. disambung = sambung_ulang(palsu, posisi + 1)
    Kembalikan tuple (palsu, disambung). Rantai asli tidak boleh berubah.
    """
    # TODO: lengkapi
    # Petunjuk: Gunakan L3.ubah_blok(...) dan L3.sambung_ulang(...)
    raise NotImplementedError("TODO: palsukan")


# ============================================================== MODIFIKASI 4
def ringkasan_saldo(bc, nama: str) -> dict:
    """Dari bc.riwayat(nama) (Level 4), hitung:
      {"masuk": total amount yang DITERIMA nama,
       "keluar": total amount yang DIKIRIM nama,
       "bersih": masuk - keluar}
    """
    # TODO: lengkapi
    # Petunjuk: Loop: for _, tx in bc.riwayat(nama): ...
    raise NotImplementedError("TODO: ringkasan_saldo")


# ============================================================== MODIFIKASI 5
class BlockchainDeterministik(L5.Blockchain):
    """Blockchain Level 5 tanpa jam komputer, agar hasilnya bisa dihitung ulang dosen:
      * genesis: {"index": 0, "timestamp": tanggal_lahir,
                  "transactions": [f"GENESIS {id_mhs}"], "previous_hash": "0"*64, "nonce": 0}
        lalu ditambang dengan self.proof_of_work dan dimasukkan ke self.chain
      * new_block(): sama seperti Level 5, tetapi timestamp = f"{tanggal_lahir} #{index}"
    """

    def __init__(self, tanggal_lahir: str, id_mhs: str, difficulty: int = 4):
        # Jangan memanggil super().__init__(), karena itu memakai datetime.now().
        # TODO: lengkapi
        # Petunjuk: Set self.difficulty, self.tanggal_lahir, self.chain = []
        # Petunjuk: Buat dict genesis sesuai docstring kelas, lalu self.proof_of_work(genesis) dan append
        raise NotImplementedError("TODO: __init__ di BlockchainDeterministik")

    def new_block(self, transactions: list) -> dict:
        # TODO: lengkapi
        # Petunjuk: Salin new_block dari Level 5, ganti hanya nilai timestamp
        raise NotImplementedError("TODO: new_block di BlockchainDeterministik")
