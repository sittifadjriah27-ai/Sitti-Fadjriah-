
"""
TUGAS PERSONAL — Lima Modifikasi Level 1–5
===========================================================

Setiap fungsi/kelas di bawah memodifikasi kode level sebelumnya
agar memakai data pribadi mahasiswa.

Jalankan:
python tugas_personal/jalankan_tugas.py --cek
"""

import level01_hash as L1
import level02_blok as L2
import level03_tampering as L3
import level05_pow_nonce as L5


# ============================================================== 
# MODIFIKASI 1 — SIDIK JARI MAHASISWA
# ==============================================================

def sidik_jari(nama: str, nim4: str, tanggal_lahir: str) -> str:
    """
    ID mahasiswa = 8 karakter pertama SHA-256 dari:
    nim4:nama:tanggal_lahir
    """

    return L1.sha256_hex(
        f"{nim4}:{nama}:{tanggal_lahir}"
    )[:8]


# ============================================================== 
# MODIFIKASI 2 — BLOCKCHAIN PERSONAL
# ==============================================================

class BlockchainPersonal(L2.Blockchain):
    """
    Blockchain Level 2 yang dipersonalisasi.

    - Proof genesis = int(nim4)
    - Setiap blok memiliki field pemilik = id_mhs
    """

    def __init__(
        self,
        nim4: str,
        id_mhs: str,
        difficulty: int = 4
    ):

        self.difficulty = difficulty
        self.id_mhs = id_mhs
        self.chain = []

        # Membuat blok genesis menggunakan NIM
        self.create_block(
            proof=int(nim4),
            previous_hash="0"
        )

    def create_block(
        self,
        proof: int,
        previous_hash: str
    ) -> dict:

        # Membuat blok menggunakan class induk
        block = super().create_block(
            proof,
            previous_hash
        )

        # Menambahkan identitas pemilik
        block["pemilik"] = self.id_mhs

        return block


# ============================================================== 
# MODIFIKASI 3 — PEMALSUAN BLOCKCHAIN
# ==============================================================

def palsukan(chain: list, posisi: int):
    """
    Melakukan pemalsuan data pada blok tertentu.

    1. Mengubah data blok.
    2. Menambahkan teks DIPALSUKAN.
    3. Menyambungkan ulang rantai.
    4. Mengembalikan dua rantai.
    """

    # Mengambil data asli
    data_baru = chain[posisi]["data"] + " (DIPALSUKAN)"

    # Mengubah blok tanpa mengubah rantai asli
    palsu = L3.ubah_blok(
        chain,
        posisi,
        "data",
        data_baru
    )

    # Menyambungkan ulang mulai blok berikutnya
    disambung = L3.sambung_ulang(
        palsu,
        posisi + 1
    )

    return palsu, disambung


# ============================================================== 
# MODIFIKASI 4 — RINGKASAN SALDO
# ==============================================================

def ringkasan_saldo(bc, nama: str) -> dict:
    """
    Menghitung:
    - Total uang masuk
    - Total uang keluar
    - Saldo bersih
    """

    masuk = 0
    keluar = 0

    # Mengambil riwayat transaksi mahasiswa
    for _, tx in bc.riwayat(nama):

        # Menghitung transaksi masuk
        if tx["recipient"] == nama:
            masuk += tx["amount"]

        # Menghitung transaksi keluar
        if tx["sender"] == nama:
            keluar += tx["amount"]

    # Mengembalikan hasil perhitungan
    return {
        "masuk": masuk,
        "keluar": keluar,
        "bersih": masuk - keluar
    }


# ============================================================== 
# MODIFIKASI 5 — BLOCKCHAIN DETERMINISTIK
# ==============================================================

class BlockchainDeterministik(L5.Blockchain):
    """
    Blockchain Level 5 menggunakan tanggal lahir
    sebagai timestamp agar hasil deterministik.

    Genesis menggunakan:
    - index = 0
    - timestamp = tanggal_lahir
    - transactions = GENESIS + id mahasiswa
    - previous_hash = 64 angka nol
    - nonce = 0
    """

    def __init__(
        self,
        tanggal_lahir: str,
        id_mhs: str,
        difficulty: int = 4
    ):

        # Mengatur atribut blockchain
        self.difficulty = difficulty
        self.tanggal_lahir = tanggal_lahir
        self.id_mhs = id_mhs
        self.chain = []

        # Membuat blok genesis
        genesis = {
            "index": 0,
            "timestamp": self.tanggal_lahir,
            "transactions": [
                f"GENESIS {self.id_mhs}"
            ],
            "previous_hash": "0" * 64,
            "nonce": 0
        }

        # Menambang blok genesis
        self.proof_of_work(genesis)

        # Memasukkan genesis ke blockchain
        self.chain.append(genesis)

    def new_block(self, transactions: list) -> dict:
        """
        Membuat blok baru dengan timestamp deterministik.
        """

        # Mengambil blok sebelumnya
        previous_block = self.chain[-1]

        # Menentukan index blok baru
        index = previous_block["index"] + 1

        # Membuat blok baru
        block = {
            "index": index,
            "timestamp": f"{self.tanggal_lahir} #{index}",
            "transactions": transactions,
            "previous_hash": previous_block["hash"],
            "nonce": 0
        }

        # Melakukan Proof of Work
        self.proof_of_work(block)

        # Menambahkan blok ke blockchain
        self.chain.append(block)

        return block
