# Laporan Tugas Personal Blockchain Level 1–5

- **Nama:** SITTI FADJRIAH
- **NIM (4 digit terakhir):** 2027
- **Dibuat:** 2026-11-14 19:43  (waktu proses 9.6 detik)
- **Kode verifikasi:** `563672DD8733`

> Bagian hasil dibuat otomatis. Jangan diubah: dosen menghitung ulang semua angka dari data Anda.
> Isi bagian **Analisis** dengan kata-kata Anda sendiri.

## Level 1 — Hash data pribadi

| Hasil | Nilai |
|---|---|
| SHA-256 nama | `7aa9803fcb9dfb25246f4de977569682b81dc1101492f73d0efe7851a507b715` |
| hash_dict profil | `bea42e1e5ce1b7ba800c5de67bd808d3ed7aead14fa970638a0dc04879c0707a` |
| hash_dict profil (urutan key dibalik) | `bea42e1e5ce1b7ba800c5de67bd808d3ed7aead14fa970638a0dc04879c0707a` |
| Bit berubah: tanggal lahir vs tanggal lahir + 1 hari | 50.0% |
| ID mahasiswa (Modifikasi 1) | `8c3a6722` |

## Level 2 — Blockchain personal

- Proof genesis: **2027** (dari NIM)
- Proof blok 2, 3, 4: **11753, 104866, 202192**
- Pemilik setiap blok: `8c3a6722`
- Rantai valid: True

## Level 3 — Pemalsuan data pribadi

- Posisi yang dipalsukan: **4**
- Data asli: `SITTI FADJRIAH NIM akhir 2027`
- Data palsu: `SITTI FADJRIAH NIM akhir 2027 (DIPALSUKAN)`
- Valid sebelum dipalsukan: True
- Tautan putus di indeks: **None**
- Valid setelah dipalsukan: **True**
- Valid setelah disambung ulang: **True**

## Level 4 — Transaksi dari data pribadi

| Blok | Pengirim | Penerima | Jumlah |
|---|---|---|---|
| 2 | SITTI FADJRIAH | TEMAN_A | 27 |
| 2 | TEMAN_A | SITTI FADJRIAH | 7 |
| 3 | SITTI FADJRIAH | DOSEN | 28 |

- Ringkasan saldo (Modifikasi 4): masuk **7**, keluar **55**, bersih **-48**
- Kirim ke diri sendiri ditolak: True
- Amount 0 ditolak: True

## Level 5 — Proof of Work dengan nonce (deterministik)

| Blok | Nonce | Hash |
|---|---|---|
| 0 | 160515 | `00005512a002ceddff86b62f…` |
| 1 | 14501 | `00007f2d53caa2262b000bc7…` |
| 2 | 107500 | `000089fd36ad4324703890ae…` |
| 3 | 75970 | `0000482d833c288a2f2d4eaa…` |

- Valid: True → setelah blok 1 dipalsukan: **False**
- Percobaan hash untuk menambang ulang blok 1–3: **358.202**
- Valid setelah ditambang ulang: True

## Analisis (isi dengan kata-kata Anda sendiri)

1. **Level 1.** Bandingkan SHA-256 nama Anda dengan milik seorang teman. Apakah ada pola yang mirip? Jelaskan juga mengapa dua hash profil Anda sama, dan mengapa hanya menambah 1 hari pada tanggal lahir mengubah 50.0% bit.

   _Jawaban:_Hash SHA-256 saya dan teman pasti memiliki nilai yang berbeda meskipun menggunakan metode yang sama. Hal ini karena setiap data yang dimasukkan menghasilkan hash yang unik. Dua hash profil saya memiliki nilai yang sama karena fungsi hash_dict mengurutkan key terlebih dahulu sebelum melakukan hashing, sehingga urutan data tidak memengaruhi hasil hash. Sementara itu, penambahan satu hari pada tanggal lahir mengubah sekitar 50% bit karena SHA-256 memiliki efek avalanche, yaitu perubahan kecil pada data dapat menghasilkan perubahan besar pada hash.

2. **Level 2.** Kode Anda dan teman sama persis, tetapi proof Anda (11753, 104866, 202192) berbeda. Jelaskan penyebabnya.

   _Jawaban:_Meskipun kode program saya dan teman sama, nilai proof yang dihasilkan bisa berbeda karena data yang digunakan berbeda. Proof bergantung pada isi blok, hash sebelumnya, dan proses Proof of Work. Pada blockchain saya, proof genesis menggunakan NIM 2027 sehingga menghasilkan nilai proof yang berbeda dengan teman. Jadi, perbedaan data pribadi dapat menyebabkan hasil proof yang berbeda meskipun menggunakan algoritma dan kode yang sama.

3. **Level 3.** Anda memalsukan posisi 4 dan tidak ada tautan putus yang terdeteksi (None), sedangkan valid setelah dipalsukan = True. Jelaskan hasil ini, lalu bandingkan dengan teman yang posisi pemalsuannya berbeda.

   _Jawaban:_Pada Level 3, saya memalsukan blok pada posisi 4 dan hasilnya tidak ditemukan tautan yang putus (None). Hal ini terjadi karena blok yang dipalsukan berada pada posisi terakhir sehingga tidak ada blok berikutnya yang menyimpan hash dari blok tersebut sebagai previous_hash. Akibatnya, perubahan data tidak terdeteksi oleh pemeriksaan tautan rantai. Berbeda dengan teman yang memalsukan blok di posisi tengah, perubahan hash dapat menyebabkan tautan ke blok berikutnya menjadi tidak sesuai sehingga pemalsuan lebih mudah terdeteksi.

4. **Level 4.** Jelaskan dari mana angka masuk 7, keluar 55, dan bersih -48 berasal. Mengapa transaksi ke diri sendiri perlu ditolak?

   _Jawaban:_Saldo masuk sebesar 7 berasal dari transaksi TEMAN_A kepada saya sebesar 7. Saldo keluar sebesar 55 berasal dari dua transaksi, yaitu 27 kepada TEMAN_A dan 28 kepada DOSEN. Jadi, saldo bersih diperoleh dari saldo masuk dikurangi saldo keluar, yaitu 7 - 55 = -48. Transaksi ke diri sendiri perlu ditolak karena tidak memberikan perpindahan uang kepada pihak lain dan dapat menyebabkan pencatatan transaksi menjadi tidak sesuai. Selain itu, jumlah transaksi sebesar 0 juga perlu ditolak karena tidak memiliki nilai perpindahan saldo.

5. **Level 5.** Penyerang butuh 358.202 percobaan hash untuk memalsukan rantai Anda. Mengapa nonce Anda selalu sama setiap kali program dijalankan, padahal di demo Level 5 asli nonce berubah-ubah?

   _Jawaban:_Nonce saya selalu sama setiap kali program dijalankan karena blockchain deterministik menggunakan data dan kondisi awal yang tetap. Timestamp menggunakan tanggal lahir, isi transaksi juga tetap, dan proses pencarian nonce selalu dimulai dari nilai awal yang sama. Oleh karena itu, hasil hash dan nonce yang ditemukan akan selalu sama. Berbeda dengan demo Level 5 asli yang menggunakan timestamp berdasarkan waktu saat program dijalankan sehingga input hash dapat berubah dan menghasilkan nonce yang berbeda.

6. **Etika data.** Anda baru saja menyimpan nama dan tanggal lahir di dalam blockchain. Jika ini blockchain publik, apa risikonya? Kaitkan dengan sifat immutability dan UU No. 27 Tahun 2022 tentang Pelindungan Data Pribadi, terutama hak untuk menghapus data.

   _Jawaban:_Jika nama dan tanggal lahir disimpan di dalam blockchain publik, data pribadi tersebut berisiko diketahui dan disalahgunakan oleh orang lain. Hal ini karena blockchain memiliki sifat immutability, yaitu data yang sudah tersimpan sulit diubah atau dihapus. Berdasarkan UU No. 27 Tahun 2022 tentang Pelindungan Data Pribadi, setiap orang memiliki hak atas perlindungan data pribadinya, termasuk hak meminta penghapusan atau pemusnahan data pribadi sesuai ketentuan yang berlaku. Oleh karena itu, menyimpan data pribadi secara langsung di blockchain publik dapat menimbulkan masalah karena bertentangan dengan kebutuhan penghapusan data. Sebaiknya data pribadi tidak disimpan secara langsung di blockchain, tetapi menggunakan kode identitas atau hash, sedangkan data aslinya disimpan di tempat yang lebih aman dan dapat dikendalikan.

---

## Data verifikasi (JANGAN DIUBAH)

<!-- DATA-VERIFIKASI -->
```json
{
  "profil": {
    "nama": "SITTI FADJRIAH",
    "nim4": "2027",
    "tanggal_lahir": "2005-07-27",
    "kota_asal": "SORONG",
    "hobi": "MEMBACA"
  },
  "level1": {
    "hash_nama": "7aa9803fcb9dfb25246f4de977569682b81dc1101492f73d0efe7851a507b715",
    "hash_profil": "bea42e1e5ce1b7ba800c5de67bd808d3ed7aead14fa970638a0dc04879c0707a",
    "hash_profil_urutan_terbalik": "bea42e1e5ce1b7ba800c5de67bd808d3ed7aead14fa970638a0dc04879c0707a",
    "avalanche_tanggal_persen": 50.0,
    "id_mahasiswa": "8c3a6722"
  },
  "level2": {
    "proof_genesis": 2027,
    "proof_blok": [
      11753,
      104866,
      202192
    ],
    "pemilik_semua_blok": [
      "8c3a6722"
    ],
    "valid": true
  },
  "level3": {
    "posisi_dipalsukan": 4,
    "data_asli": "SITTI FADJRIAH NIM akhir 2027",
    "data_palsu": "SITTI FADJRIAH NIM akhir 2027 (DIPALSUKAN)",
    "valid_asli": true,
    "tautan_putus_di": null,
    "valid_setelah_dipalsukan": true,
    "valid_setelah_disambung_ulang": true
  },
  "level4": {
    "riwayat": [
      [
        2,
        {
          "sender": "SITTI FADJRIAH",
          "recipient": "TEMAN_A",
          "amount": 27
        }
      ],
      [
        2,
        {
          "sender": "TEMAN_A",
          "recipient": "SITTI FADJRIAH",
          "amount": 7
        }
      ],
      [
        3,
        {
          "sender": "SITTI FADJRIAH",
          "recipient": "DOSEN",
          "amount": 28
        }
      ]
    ],
    "ringkasan_saldo": {
      "masuk": 7,
      "keluar": 55,
      "bersih": -48
    },
    "kirim_ke_diri_sendiri_ditolak": true,
    "amount_nol_ditolak": true,
    "jumlah_blok": 3
  },
  "level5": {
    "nonce": [
      160515,
      14501,
      107500,
      75970
    ],
    "hash": [
      "00005512a002ceddff86b62f22aab3582257bbbd94367203e3599bc69c4a7e1a",
      "00007f2d53caa2262b000bc715c0915a7c583df3e4646133adfe108052caec6d",
      "000089fd36ad4324703890ae2c62c64a2a52f81407b4792fa3d50e88a0667b22",
      "0000482d833c288a2f2d4eaa314788f823d4b3ff404e66d5ae00dcd75c61798f"
    ],
    "valid": true,
    "valid_setelah_dipalsukan": false,
    "percobaan_tambang_ulang": 358202,
    "valid_setelah_tambang_ulang": true
  },
  "kode_verifikasi": "563672DD8733"
}
```
